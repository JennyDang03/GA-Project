
library("arrow")
library(psych)
install.packages("psych")


df <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/Pix_ind_sample_PF.parquet")
pix_pj <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/Pix_ind_sample_PJ.parquet")

pix_pj <- 
setwd("//sbcdf060/depep$/DEPEPCOPEF/Teradata slicer")

df <- read_dta("//sbcdf176/PIX_Matheus$/Stata/dta/Credito_Muni_PF.dta")

cadastro <- read_csv("//sbcdf176/PIX_Matheus$/DadosOriginais/random_sample_PF_cadastro.csv")
cadastroPJ <- read_csv("//sbcdf176/PIX_Matheus$/DadosOriginais/random_sample_PJ_cadastro.csv")

TED_STR_B2P <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/TED_STR_B2P_teradata_2018-03-12.parquet")
TED_STR_B2P_SITRAF <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/TED_SITRAF_B2P_teradata_2018-03-12.parquet")

TED_STR_B2B <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/TED_STR_B2B_teradata_2018-03-12.parquet")
TED_STR_B2B_SITRAF <- read_parquet("//sbcdf176/PIX_Matheus$/DadosOriginais/TED_SITRAF_B2B_teradata_2018-03-12.parquet")
