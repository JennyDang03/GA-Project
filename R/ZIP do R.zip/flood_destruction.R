#flood_destruction.R



#https://lost-stats.github.io/Model_Estimation/Research_Design/event_study.html

options(download.file.method = "wininet")

#install.packages(c("data.table","fixest","haven","ggplot2"))

library(data.table) ## For some minor data wrangling
library(fixest)     ## NB: Requires version >=0.9.0
library(haven)
library(ggplot2)
library(dplyr)

rm(list = ls()) ## Clear workspace

setwd("//sbcdf176/Pix_Matheus$")

# Set file paths
log_path <- "//sbcdf176/PIX_Matheus$/Stata/log"
dta_path <- "//sbcdf176/PIX_Matheus$/Stata/dta"
output_path <- "//sbcdf176/PIX_Matheus$/Output"
origdata_path <- "//sbcdf176/PIX_Matheus$/DadosOriginais"
R_path <- "//sbcdf176/PIX_Matheus$/R"
#dta_path <- "C:/Users/mathe/Dropbox/RESEARCH/pix/pix-event-study/Stata/dta"
#output_path <- "C:/Users/mathe/Dropbox/RESEARCH/pix/pix-event-study/Output/tables"
#log_path <- "C:/Users/mathe/Dropbox/RESEARCH/pix/pix-event-study/Stata/log"

log_file <- file.path(log_path, "flood_destruction.log")
#sink(log_file) ## redirect R output to log file

# Graph TWFE and SA
################################################################################
graph_function9 <- function(y,dat){
  dat$Y <- dat[[y]]
  
  mod_twfe = feols(Y ~ i(time_to_treat, treat, ref = -1) | ## Our key interaction: time ? treatment status
                     muni_cd + ano,            ## FEs
                   cluster = ~muni_cd,                          ## Clustered SEs
                   data = dat)
  
  return(mod_twfe)
}
graph_function15 <- function(y,dat){
  dat$Y <- dat[[y]]
  
  mod_twfe = feols(Y ~ i(time_to_treat, treat, ref = -1) | ## Our key interaction: time ? treatment status
                     muni_cd + ano + flood_risk:ano + rural_urban:ano + nome_regiao_code:ano + pop2010_quart:ano + capital_uf:ano,            ## FEs
                   cluster = ~muni_cd,                          ## Clustered SEs
                   data = dat)
  
  return(mod_twfe)
}

graph_function18 <- function(y,dat,xlimit_l,xlimit_u, main_title){
  png(file.path(output_path,paste0("flood_destruction_",y,"nocontrol.png")), width = 640*4, height = 480*4, res = 200)
  iplot(graph_function9(y,dat), sep = 0.5, ref.line = -1,
        xlab = 'Year',
        main = main_title,
        ci_level = 0.95, xlim = c(xlimit_l-0.5,xlimit_u+0.5))
  
  legend("bottomleft", col = c(1), pch = c(20), 
         legend = c("TWFE"), cex = 0.8)
  dev.off()
  
  png(file.path(output_path,paste0("flood_destruction_",y,"control.png")), width = 640*4, height = 480*4, res = 200)
  iplot(graph_function15(y,dat), sep = 0.5, ref.line = -1,
        xlab = 'Year',
        main = main_title,
        ci_level = 0.95, xlim = c(xlimit_l-0.5,xlimit_u+0.5))
  
  legend("bottomleft", col = c(1), pch = c(20), 
         legend = c("TWFE"), cex = 0.8)
  dev.off()
}

################################################################################
# Flood at the Municipal level - Monthly Level
################################################################################

#####################
# After Pix
#####################

# Load already prepared data!
dat_flood <- read_dta(file.path(dta_path,"flood_pib_mun.dta"))
mun_fe <- read_dta(file.path(dta_path, "mun_fe.dta"))
dat_flood <- merge(dat_flood, mun_fe)

ppm_pam <- read_dta(file.path(dta_path, "ppm_pam_flood.dta"))
ppm_pam <- ppm_pam %>%
  select(-after_flood, -date_flood, -flood, -number_disasters)
dat_flood <- merge(dat_flood, ppm_pam, by = c("ano","id_municipio"), all.x = TRUE, all.y = TRUE)

# converts to data.table
setDT(dat_flood)

dat_flood[, treat := ifelse(is.na(date_flood), 0, 1)]
table(dat_flood$treat)
dat_flood[, time_to_treat := ifelse(treat==1, ano - date_flood, 0)]
table(dat_flood$time_to_treat)
# Following Sun and Abraham, we give our never-treated units a fake "treatment" date far outside the relevant study period.
dat_flood[, time_id_treated := ifelse(treat==0, 1000000, date_flood)]
table(dat_flood$time_id_treated)

# Set Limits
xlimit_low <- -3
xlimit_up <- 2
xlimits <- seq(ceiling(xlimit_low*1.1-10),ceiling(xlimit_up*1.1+10),by=1)
dat_flood <- subset(dat_flood,time_to_treat %in% xlimits)
#


dat_flood[, log_pib := log(pib + 1)]
graph_function18("log_pib",dat_flood, xlimit_low, xlimit_up, "Log GDP")
graph_function18("log_production",dat_flood, xlimit_low, xlimit_up, "Log Production")
graph_function18("log_production_animal",dat_flood, xlimit_low, xlimit_up, "Log Production")
graph_function18("log_production_fish",dat_flood, xlimit_low, xlimit_up, "Log Production")
graph_function18("log_production_perm",dat_flood, xlimit_low, xlimit_up, "Log Production")
graph_function18("log_production_temp",dat_flood, xlimit_low, xlimit_up, "Log Production")
