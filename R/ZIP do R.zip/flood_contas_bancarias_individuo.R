#flood_contas_bancarias_individuo
#before and after pix

# Pix_bank_account.dta + flood