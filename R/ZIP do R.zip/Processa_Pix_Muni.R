# Process data to create dta file
options(download.file.method = "wininet")
rm(list = ls())
library(readr)
library(stringr)
library(odbc)
library(dplyr)
library(tidyr)
library(RODBC)
library(futile.logger)
library(data.table)
library(bit64)
library(haven)
library(gdata)
#install.packages("arrow")
library("arrow")

setwd("//sbcdf060/depep$/DEPEPCOPEF/Teradata slicer")
source("./functions/parametrizeQuery.R")
source("./functions/extractTeradataDataSEDE.R")

path_query <- "//sbcdf176/PIX_Matheus$/R/DataExtraction/"
path_data <- "//sbcdf176/PIX_Matheus$/DadosOriginais/"
path_dta <- "//sbcdf176/PIX_Matheus$/Stata/dta/" 


tipo <- c("Pix_Muni_self", "Pix_Muni_inflow","Pix_Muni_outflow","Pix_Muni_intra")
data_pix = read_parquet(paste0(path_data, tipo[1], ".parquet"), as_tibble = TRUE)
data_pix = read_parquet(paste0(path_data, tipo[2], ".parquet"), as_tibble = TRUE)

for(i in 2:length(tipo)) {
  teste <- read_parquet(paste0(path_data, tipo[i], ".parquet"), as_tibble = TRUE)
  data_pix <- rbindlist(list(data_pix, teste), fill=TRUE)   
}

# Needs to fill the data. Some muni_cd have weeks with no transactions for example. 
data_pix %>%
  complete(
    week,
    nesting(muni_cd, sender_type, receiver_type, flow_code),
    fill = list(senders = 0, receivers = 0, value = 0, trans=0, value_w = 0),
    explicit = FALSE)

# Add Flood - keep only matches. 

# Load Flood data -> keep only date_flood. 
flood_data <- read_dta(paste0(path_dta,"flood_weekly_2020_2022.dta"))
#flood_data <- read_dta("C:/Users/mathe/Dropbox/RESEARCH/pix/pix-event-study/Stata/dta/flood_weekly_2020_2022.dta")
flood_data <- flood_data %>%
  select(muni_cd, week, date_flood)

data_pix <- data_pix %>%
  inner_join(flood_data, by = c("muni_cd", "week"))

# Add Log
data_pix <- data_pix %>%
  mutate(
    lvalue = log1p(valor),
    ltrans = log1p(trans),
    lvalue_w = log1p(valor_w),
    lsenders = log1p(senders),
    lreceivers = log1p(receivers)
  )

# write data
write_dta(data_pix, paste0(path_dta,"base_pix_muni",".dta"))
# Variables: date_flood, flow_code, week, muni_cd, sender_type, receiver_type, senders, receivers, value, trans, value_w,
#             lsenders, lreceivers, lvalue, ltrans, lvalue_w


## PIX BANK X MUNI
# Needs to fill the data. Some muni_cd have weeks with no transactions for example. 
data %>%
  complete(
    week,
    nesting(muni_cd, tipo, bank),
    fill = list(value_send = 0, trans_send = 0, send_users = 0, value_send_w = 0, value_rec = 0, trans_rec = 0, rec_users = 0, value_rec_w = 0),
    explicit = FALSE)

# Add Flood - keep only matches. 
data <- data %>%
  inner_join(flood_data, by = c("muni_cd", "week"))

# Add Log
data <- data %>%
  mutate(
    lvalue_send = log1p(value_send),
    ltrans_send = log1p(trans_send),
    lsend_users = log1p(send_users),
    lvalue_send_w = log1p(value_send_w),
    lvalue_rec = log1p(value_rec),
    ltrans_rec = log1p(trans_rec),
    lrec_users = log1p(rec_users),
    lvalue_rec_w = log1p(value_rec_w)      
  )

# Download data
write_dta(data, paste0(path_dta,tipo[i],".dta"))
# Variables: date_flood, week, muni_cd, tipo, bank, value_send, trans_send, send_users, value_send_w, value_rec, trans_rec, rec_users, value_rec_w
#             lvalue_send, ltrans_send, lsend_users, lvalue_send_w, lvalue_rec, ltrans_rec, lrec_users, lvalue_rec_w


## CCS BANCO X MUNI
# Needs to fill the data. Some muni_cd have weeks with no transactions for example. 
data %>%
  complete(
    week,
    nesting(muni_cd, tipo, bank),
    fill = list(opening = 0, closing = 0, stock = 0),
    explicit = FALSE)

# Add Flood - keep only matches. 
data <- data %>%
  inner_join(flood_data, by = c("muni_cd", "week"))

# Add Log
data <- data %>%
  mutate(
    lopening = log1p(opening),
    lclosing = log1p(closing),
    lstock = log1p(stock)    
  )

# Download data
write_dta(data, paste0(path_dta,tipo[i],".dta"))
# Variables: date_flood, week, muni_cd, tipo, bank, opening, stock, closing
#             lopening, lstock, lclosing

